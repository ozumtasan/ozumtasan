﻿
using UnityEngine;

public class PlayerCollesion : MonoBehaviour
{
    public PlayerMovement movement;
    

     void OnCollisionEnter(Collision collesionInfo)
    {
        Debug.Log(collesionInfo.collider.name);
        if (collesionInfo.collider.tag =="Obstacle")
        {
            Debug.Log(" Warning!");
            movement.enabled = false;

            FindObjectOfType<GameManager>().EndGame();
            
        }
    }
}
